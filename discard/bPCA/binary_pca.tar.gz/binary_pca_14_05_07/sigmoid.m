
function S = sigmoid(X);

S = ( 1+ exp(-X)) .^ (-1);