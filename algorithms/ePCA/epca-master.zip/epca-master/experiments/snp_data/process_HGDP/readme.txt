subset of HGDP dataset 
obtained from Nick Patterson, 10/5/2016
in PLINK format
60 samples, from 3 populations, 
cca 100,000 SNPS

yfhx.geno, yfhx.ind, yfhx.pops, yfhx.snp

process.m - processes the file into matlab format
corr_prune.m - normalize and prune X for correlations
